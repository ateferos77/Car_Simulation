// Copyright 2016 Gabriele Sales <gbrsales@gmail.com>

var Simulation = (function() {
  'use strict';

  var ground,
      car,
      states;

  function decode(buf) {
    var car_offset = decode_ground(buf),
        states_offset = decode_car(buf, car_offset);
    decode_states(buf, states_offset);
  }

  function decode_ground(buf) {
    var sz_arr = new Uint32Array(buf),
	tile_num = sz_arr[0];

    ground = new Float32Array(buf, 4, tile_num*8);
    return 4 * (1 + 8*tile_num);
  }

  function decode_car(buf, offset) {
    car = Car.from_array(new Float32Array(buf, offset, Car.entry_num));
    return offset + 4*Car.entry_num;
  }

  function decode_states(buf, offset) {
    states = new Float32Array(buf, offset);
  }

  return {
    fetch: function(callback) {
      var req = new XMLHttpRequest();
      req.open("GET", "/simulation", true);
      req.responseType = "arraybuffer";

      req.onload = function(evt) {
        var buf = req.response;
        if (!buf)
          callback(false);

        decode(buf);
        callback(true);
      }

      req.send(null);
    },

    ground_points: function() {
      return ground;
    },

    car_spec: function() {
      return car;
    },

    state_at: function(i) {
      var b = i*9;
      if (states.length < b+9)
        return null;

      return {
        frame: {
          x:     states[b],
          y:     states[b+1],
          angle: states[b+2]
        },
        left_wheel: {
          x:     states[b+3],
          y:     states[b+4],
          angle: states[b+5]
        },
        right_wheel: {
          x:     states[b+6],
          y:     states[b+7],
          angle: states[b+8]
        }
      };
    }
  };

})();
