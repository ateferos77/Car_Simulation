// Copyright 2016 Gabriele Sales <gbrsales@gmail.com>

var UI = (function() {

  var width = 800.,
      height = 478.,
      full_height = 480.,
      scale = 20.;

  return function(parent_id, simulation) {

    var pic = null,
        msg = null,
        frame = null,
        left_wheel = null,
        right_wheel = null,
        start_time = null;

    function reset(parent) {
      parent.innerHTML = '';
    }

    function create_message(parent) {
      var d = document.createElement('div');
      parent.appendChild(d);
      return d;
    }

    function show_state(state) {
      msg.innerHTML = 'State: <strong>' + state.toUpperCase() + '</strong>';
    }


    function create_ground(points) {
      var color = '#999';

      polygons(points).forEach(function(poly) {
        pic.polygon(poly)
          .fill(color)
          .stroke({ width: 1, color: color })
          .back();
      });
    }

    function polygons(points) {
      var i = 0,
          polygons = [];

      while (i < points.length) {
        var x, y, poly = '';

        for (j = 0; j < 4; j++, i += 2) {
          x = points[i] * scale;
          y = height - points[i+1]*scale;
          poly += x + ',' + y + ' ';
        }

        polygons.push(poly);
      }

      return polygons;
    }


    function create_car(spec) {
      frame = create_frame(spec.frame_points);
      left_wheel = create_wheel(spec.left_wheel_radius);
      right_wheel = create_wheel(spec.right_wheel_radius);
    }

    function create_frame(points) {
      var color = '#bbb',
	  frame = pic.group();

      polygons(points).forEach(function(poly) {
        frame.polygon(poly)
          .fill(color)
          .stroke({color: color, width: 1});
      });

      return frame;
    }

    function create_wheel(radius) {
      var color = '#444',
	  wheel = pic.group();

      wheel.circle(2. * radius * scale)
        .center(0., height)
        .fill(color);

      return wheel;
    }


    function update(timestamp) {
      if (!start_time) start_time = timestamp;
      delta = timestamp - start_time;

      var step = Math.round(30. * delta / 1000.),
          st = simulation.state_at(step);

      if (!st) {
        show_state('done');
        return;
      }

      var frame_x = update_group(st.frame, frame);
      update_group(st.left_wheel, left_wheel);
      update_group(st.right_wheel, right_wheel);
      window.requestAnimationFrame(update);

      var center = width / 2.;
      if (frame_x > center) {
        var view = pic.viewbox();
        view.x = frame_x - center;
        pic.viewbox(view);
      }
    }

    function update_group(state, group) {
      var x = state.x * scale,
          y = -state.y * scale,
          angle = -state.angle * 180. / Math.PI;

      var tx = 'translate(' + x + ' ' + y + ') ' +
          'rotate(' + angle + ' 0 ' + height + ')';
      group.attr('transform', tx);

      return x;
    }


    var parent = document.getElementById(parent_id);
    reset(parent);
    pic = SVG(parent_id).size(width, full_height);
    msg = create_message(parent);

    create_ground(simulation.ground_points());
    create_car(simulation.car_spec());

    show_state('running');
    requestAnimationFrame(update);
  }

})();
