// Copyright 2016 Gabriele Sales <gbrsales@gmail.com>

var Events = (function() {
  'use strict';

  return {
    subscribe: function(callback) {
      var source = new EventSource('/events');
      source.addEventListener('message', function(e) { callback(e.data); },
                              false);
    }
  };

})();
