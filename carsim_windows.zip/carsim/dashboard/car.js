// Copyright 2016 Gabriele Sales <gbrsales@gmail.com>

var Car = (function() {
  'use strict';

  return {
    from_array: function(arr) {
      return {
        frame_points:       new Float32Array(arr.buffer, arr.byteOffset, 32),
        left_wheel_radius:  arr[32],
        right_wheel_radius: arr[33]
      };
    },

    entry_num: 34
  };

})();
