// Copyright 2016 Gabriele Sales <gbrsales@gmail.com>

(function() {
  'use strict';

  function setup() {
    document.addEventListener("DOMContentLoaded", function() {
      Events.subscribe(handle_event);
      //handle_event('SIM');
    });
  }

  function handle_event(evt) {
    if (evt != 'SIM')
      return;

    Simulation.fetch(function(success) {
      if (!success) {
        alert('Cannot fetch simulation data.');
        return;
      }

      UI('output', Simulation);
    });
  }


  setup();

})();
